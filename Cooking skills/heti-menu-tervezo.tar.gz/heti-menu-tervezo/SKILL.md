---
name: heti-menu-tervezo
description: >
  Családi heti ebéd és vacsora menüterv készítése bevásárlólistával, receptekkel és tápanyag-információval.
  Használd ezt a skill-t, amikor a felhasználó heti menüt, étkezési tervet, ebéd- vagy vacsoratervet kér,
  bevásárlólistát szeretne, receptötleteket keres a hétre, vagy bármilyen családi étkezés-tervezésről van szó.
  Akkor is triggerelődj, ha a felhasználó azt mondja: "mit főzzek", "mit együnk", "tervezd meg a hetet",
  "bevásárlólista", "heti kaja", "menüterv", vagy hasonló. Még akkor is használd, ha nem mondja ki
  kifejezetten hogy "menüterv" — ha étkezés-tervezésről van szó, ez a skill kell.
---

# Családi Heti Menütervező

Segíts a családnak megtervezni a heti ebéd és vacsora menüt! A család 2 felnőttből és 3 gyerekből áll (7, 5 és 3 évesek).

## Alapelvek

### Gyerekbarát szemlélet
A 3-7 éves korosztály igényei kiemelt fontosságúak. Ez azt jelenti:
- Az ételek ne legyenek túl fűszeresek vagy csípősek
- Legyenek ismerős textúrák és ízek, de időnként vezess be új dolgokat is óvatosan
- A zöldségek és gyümölcsök legyenek vonzóan tálalva
- Az adagméretek legyenek gyerekméretben is megadva

### Kedvencek rendszere
A családnak lehetnek kedvenc ételei. Amikor a felhasználó említi hogy valami kedvenc, vagy hogy "ezt szeretjük", jegyezd meg és a következő tervezésnél vedd figyelembe. Kérdezz rá a kedvencekre az első alkalommal!

Ha a felhasználó egy `kedvencek.md` fájlt tart karban a projektben, olvasd be és használd tervezéskor. A fájl formátuma:

```markdown
# Család kedvenc ételei
## Mindenki szereti
- Rántott csirke
- Bolognai spagetti

## Gyerekek kedvence
- Palacsinta
- Virslis tészta

## Felnőttek kedvence  
- Töltött paprika
- Csirkepaprikás
```

### Változatosság
- Egy héten belül ne ismétlődjenek az alapanyagok túl gyakran (pl. ne legyen 4 napon csirke)
- Váltogasd a fehérjeforrásokat: csirke, sertés, marha, hal, tojás, hüvelyesek
- Legyen legalább 1 húsmentes nap a héten
- A konyha stílusok keveredjenek: magyar, nemzetközi, egészségtudatos, gyors receptek

### Praktikusság
- Hétköznap esti vacsorákhoz gyors (30-45 perces) recepteket adj
- Hétvégén megengedhető az igényesebb, hosszabb főzés
- Gondolj a maradék-újrahasznosításra (pl. vasárnapi sült csirke → hétfői csirkesaláta)
- Az ebédek lehetnek könnyedebbek, a vacsorák tartalmasabbak

## Munkafolyamat

### 1. lépés: Információgyűjtés

Első alkalommal (vagy ha még nincs `kedvencek.md`):
1. Kérdezd meg, milyen ételeket szeret a család (kedvencek)
2. Van-e bármi, amit nem szeretnek vagy nem ehetnek
3. Van-e speciális alkalom a héten (születésnap, vendégek)
4. Mekkora a heti büdzsé (opcionális)

Ha már van `kedvencek.md`, olvasd be és erősítsd meg: "Látom a kedvenceket, ezek alapján tervezek. Van valami változás?"

### 2. lépés: Menüterv összeállítása

Készíts egy markdown fájlt az alábbi struktúrával. A fájl neve legyen: `heti-menu-YYYY-WNN.md` (pl. `heti-menu-2026-W08.md`).

A menüterv felépítése:

```markdown
# 🍽️ Heti Menüterv — [dátum héfőtől vasárnapig]

## Heti áttekintés

| Nap | Ebéd | Vacsora |
|-----|------|---------|
| Hétfő | ... | ... |
| Kedd | ... | ... |
| Szerda | ... | ... |
| Csütörtök | ... | ... |
| Péntek | ... | ... |
| Szombat | ... | ... |
| Vasárnap | ... | ... |

---

## Hétfő

### 🥣 Ebéd: [étel neve]
**Elkészítési idő:** X perc | **Adag:** 2 felnőtt + 3 gyerek
**Kalória:** ~XXX kcal/felnőtt adag | ~XXX kcal/gyerek adag

**Hozzávalók:**
- ... (mennyiségek 5 főre, zárójelben gyerekadagok jelölve)

**Elkészítés:**
1. ...
2. ...
3. ...

**💡 Tipp:** [praktikus tipp, pl. előkészítés, tálalás gyerekeknek]

### 🍲 Vacsora: [étel neve]
[ugyanez a struktúra]

---

[... további napok ...]

---

## 🛒 Bevásárlólista

### Hús, hal
- [ ] ...

### Tejtermékek, tojás
- [ ] ...

### Zöldség, gyümölcs
- [ ] ...

### Szárazáru, fűszerek
- [ ] ...

### Egyéb
- [ ] ...

---

## 📊 Heti tápanyag-összesítő

| Nap | Ebéd kcal | Vacsora kcal | Összesen |
|-----|-----------|-------------|----------|
| Hétfő | ... | ... | ... |
| ... | ... | ... | ... |
| **Heti átlag** | **...** | **...** | **...** |

> A kalóriaértékek becsült értékek, felnőtt adagokra vonatkoznak.
> Gyerekadagok általában a felnőtt adag 50-70%-a (korcsoporttól függően).
```

### 3. lépés: Bevásárlólista optimalizálás

A bevásárlólista legyen:
- Kategóriákba rendezve (hogy a boltban könnyen végig lehessen menni)
- Összesítve (ha több recepthez kell csirkemell, az összes mennyiség egy tételben)
- Checkbox formátumban (`- [ ]`) hogy kinyomtatva vagy digitálisan is kényelmes legyen
- Becsült mennyiségekkel (5 fős családra kalkulálva)

### 4. lépés: Kedvencek frissítése

Ha az interakció során kiderül új kedvenc étel, ajánld fel a `kedvencek.md` frissítését.

## Receptek irányelvei

### Magyar/hagyományos ételek
Klasszikus magyar receptek családbarát változatai. Példák: gulyásleves, pörkölt, töltött káposzta, rántott hús, lecsó, paprikás krumpli, túrós tészta.

### Egészségtudatos
Alacsonyabb kalória, több zöldség, teljes kiőrlésű gabonák, kevesebb cukor. De ne legyen "diétás" ízű — a gyerekeknek is ízlenie kell!

### Nemzetközi
Világkonyha gyerekbarát változatai: pizza, pasta, wok, burrito, curry (enyhe). Ezek jók a változatossághoz és a gyerekek általában szeretik.

### Gyors receptek (30 perc alatt)
Hétköznap estékre ideális: egyedényes ételek, tészták, szendvicsek, omlett, saláták.

## Kimenet

A végső kimenet egyetlen, átfogó markdown fájl, ami tartalmazza:
1. Heti áttekintő táblázat
2. Napi bontás receptekkel (minden napra ebéd + vacsora)
3. Összesített bevásárlólista
4. Tápanyag-összesítő táblázat

A fájlt mentsd a munkakönyvtárba `heti-menu-YYYY-WNN.md` néven.
